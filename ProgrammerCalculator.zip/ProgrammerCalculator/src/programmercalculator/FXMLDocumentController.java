/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programmercalculator;

import java.net.URL;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.util.Callback;
import java.util.Vector;

/**
 *
 * @author nayen
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML private TextField displayOct, displayBin, displayHex, displayDec;
    @FXML private TextArea displayCalc;
    private ProgCalc pc = new ProgCalc();
    StringBuilder temp = new StringBuilder();
    StringBuilder temp2 = new StringBuilder();
    StringBuilder temp3 = new StringBuilder();
    StringBuilder temp4 = new StringBuilder();
    String num, num1, num2, num3;
    String bNum1 = "", bNum2 = "0", bOp;
    String oNum1 = "", oNum2 ="0", oOp;
    String dNum1 = "", dNum2 ="0", dOp;
    String hNum1 = "", hNum2 = "0", hOp;
    
    
    @FXML private void handleBinary(ActionEvent event) {
        String text = ((Button)event.getSource()).getText();
        temp.append(text);
        num = ProgCalc.createHex(temp.toString(), 2);
        num1 = ProgCalc.createDec(temp.toString(), 2);
        num2 = ProgCalc.createOct(temp.toString(), 2);
        num3 = temp.toString();
        displayCalc.setText(num3);
        displayHex.setText("Hex " + num);
        displayDec.setText("Dec " + num1);
        displayOct.setText("Oct " + num2);
        displayBin.setText("Bin " + num3);
    }
    @FXML private void handleOct(ActionEvent event) {
        String text = ((Button)event.getSource()).getText();  
        temp2.append(text);
        num = ProgCalc.createHex(temp2.toString(), 8);
        num1 = ProgCalc.createDec(temp2.toString(), 8);
        num2= temp2.toString();
        num3 = ProgCalc.createBin(temp2.toString(), 8);
        displayCalc.setText(num2);
        displayHex.setText("Hex " + num);
        displayDec.setText("Dec " + num1);
        displayOct.setText("Oct " + num2);
        displayBin.setText("Bin " + num3);
    }
    @FXML private void handleDec(ActionEvent event) {
        String text = ((Button)event.getSource()).getText();
        temp3.append(text);
        num = ProgCalc.createHex(temp3.toString(), 0);
        num1 = temp3.toString();
        num2= ProgCalc.createOct(temp3.toString(), 0);
        num3 = ProgCalc.createBin(temp3.toString(), 0);
        displayCalc.setText(num1);
        displayHex.setText("Hex " + num);
        displayDec.setText("Dec " + num1);
        displayOct.setText("Oct " + num2);
        displayBin.setText("Bin " + num3);
    }
    @FXML private void handleHex(ActionEvent event) {
        String text = ((Button)event.getSource()).getText();
        temp4.append(text);
        num = temp4.toString();
        num1 = ProgCalc.createDec(temp4.toString(), 16);
        num2= ProgCalc.createOct(temp4.toString(), 16);
        num3 = ProgCalc.createBin(temp4.toString(), 16);
        displayCalc.setText(num);
        displayHex.setText("Hex " + num);
        displayDec.setText("Dec " + num1);
        displayOct.setText("Oct " + num2);
        displayBin.setText("Bin " + num3);
    }
    @FXML private void handleCalcBin(ActionEvent event) {
        if(bNum1.equals("")){
            bNum1 = temp.toString();
            bOp = ((Button)event.getSource()).getText();
            temp.setLength(0);
            displayCalc.setText(bNum1);
        }else{
            bNum2 = temp.toString();
            temp.setLength(0);
            bNum1 = ProgCalc.calc(bNum1, bNum2, bOp, 2);
            bNum1 = ProgCalc.createBin(bNum1, 0);
            bNum2 = "0";
            bOp = ((Button)event.getSource()).getText();
            num = ProgCalc.createHex(bNum1, 2);
            num1 = ProgCalc.createDec(bNum1, 2);
            num2 = ProgCalc.createOct(bNum1, 2);
            num3 = bNum1;
            displayCalc.setText(num3);
            displayHex.setText("Hex " + num);
            displayDec.setText("Dec " + num1);
            displayOct.setText("Oct " + num2);
            displayBin.setText("Bin " + num3);
        }
    }
    @FXML private void handleCalcOct(ActionEvent event) {
        if(oNum1.equals("")){
            oNum1 = temp2.toString();
            oOp = ((Button)event.getSource()).getText();
            temp2.setLength(0);
            displayCalc.setText(oNum1);
        }else{
            oNum2 = temp2.toString();
            temp2.setLength(0);
            oNum1 = ProgCalc.calc(oNum1, oNum2, oOp, 8);
            oNum1 = ProgCalc.createBin(oNum1, 0);
            bOp = ((Button)event.getSource()).getText();
            num = ProgCalc.createHex(oNum1, 8);
            num1 = ProgCalc.createDec(oNum1, 8);
            num2 = oNum1;
            num3 = ProgCalc.createBin(oNum1, 8);
            displayCalc.setText(num2);
            displayHex.setText("Hex " + num);
            displayDec.setText("Dec " + num1);
            displayOct.setText("Oct " + num2);
            displayBin.setText("Bin " + num3);
        }
    }
    
    @FXML private void handleCalcDec(ActionEvent event) {
        if(dNum1.equals("")){
            dNum1 = temp3.toString();
            dOp = ((Button)event.getSource()).getText();
            temp3.setLength(0);
            displayCalc.setText(dNum1);
        }else{
            dNum2 = temp3.toString();
            temp3.setLength(0);
            dNum1 = ProgCalc.calc(dNum1, dNum2, dOp, 0);
            dNum1 = ProgCalc.createBin(dNum1, 0);
            bOp = ((Button)event.getSource()).getText();
            num = ProgCalc.createHex(dNum1, 0);
            num1 = dNum1;
            num2 = ProgCalc.createOct(dNum1, 0);
            num3 = ProgCalc.createBin(dNum1, 0);
            displayCalc.setText(num1);
            displayHex.setText("Hex " + num);
            displayDec.setText("Dec " + num1);
            displayOct.setText("Oct " + num2);
            displayBin.setText("Bin " + num3);
        }
    }
    
    @FXML private void handleCalcHex(ActionEvent event) {
        if(hNum1.equals("")){
            hNum1 = temp4.toString();
            hOp = ((Button)event.getSource()).getText();
            temp4.setLength(0);
            displayCalc.setText(hNum1);
        }else{
            hNum2 = temp4.toString();
            temp4.setLength(0);
            hNum1 = ProgCalc.calc(hNum1, hNum2, hOp, 16);
            hNum1 = ProgCalc.createBin(bNum1, 0);
            hOp = ((Button)event.getSource()).getText();
            num = hNum1;
            num1 = ProgCalc.createDec(hNum1, 16);
            num2 = ProgCalc.createOct(hNum1, 16);
            num3 = ProgCalc.createBin(hNum1, 16);
            displayCalc.setText(num);
            displayHex.setText("Hex " + num);
            displayDec.setText("Dec " + num1);
            displayOct.setText("Oct " + num2);
            displayBin.setText("Bin " + num3);
        }
    }
    
    @FXML private void handleNotBin(ActionEvent event) {
        String bNot = ProgCalc.calcNot(temp.toString(), 2);
        num = ProgCalc.createHex(bNot, 2);
        num1 = ProgCalc.createDec(bNot, 2);
        num2 = ProgCalc.createOct(bNot, 2);
        num3 = bNot;
        temp.setLength(0);
        displayCalc.setText(num3);
        displayHex.setText("Hex " + num);
        displayDec.setText("Dec " + num1);
        displayOct.setText("Oct " + num2);
        displayBin.setText("Bin " + num3);
    }   
    @FXML private void handleNotOct(ActionEvent event) {
        String bNot = ProgCalc.calcNot(temp2.toString(), 8);
        num = ProgCalc.createHex(bNot, 8);
        num1 = ProgCalc.createDec(bNot, 8);
        num2 = bNot;
        num3 = ProgCalc.createBin(bNot, 8);
        temp2.setLength(0);
        displayCalc.setText(num2);
        displayHex.setText("Hex " + num);
        displayDec.setText("Dec " + num1);
        displayOct.setText("Oct " + num2);
        displayBin.setText("Bin " + num3);
    } 
    @FXML private void handleNotDec(ActionEvent event) {
        String bNot = ProgCalc.calcNot(temp3.toString(), 0);
        num = ProgCalc.createHex(bNot, 0);
        num1 = bNot;
        num2 = ProgCalc.createOct(bNot, 0);
        num3 = ProgCalc.createBin(bNot, 0);
        temp3.setLength(0);
        displayCalc.setText(num1);
        displayHex.setText("Hex " + num);
        displayDec.setText("Dec " + num1);
        displayOct.setText("Oct " + num2);
        displayBin.setText("Bin " + num3);
    } 
    @FXML private void handleNotHex(ActionEvent event) {
        String bNot = ProgCalc.calcNot(temp4.toString(), 16);
        num = bNot;
        num1 = ProgCalc.createDec(bNot, 16);
        num2 = ProgCalc.createOct(bNot, 16);
        num3 = ProgCalc.createHex(bNot, 16);
        temp4.setLength(0);
        displayCalc.setText(num);
        displayHex.setText("Hex " + num);
        displayDec.setText("Dec " + num1);
        displayOct.setText("Oct " + num2);
        displayBin.setText("Bin " + num3);
    } 
    @FXML private void clearAll(ActionEvent event){
        bNum1 = "";bNum2 = "";bOp="";
        oNum1 = "";oNum2 = "";oOp="";
        dNum1 = "";dNum2 = "";dOp="";
        hNum1 = "";hNum2 = "";hOp="";
        temp.setLength(0);
        temp2.setLength(0);
        temp3.setLength(0);
        temp4.setLength(0);
        num = "";num1="";num2=""; num3="";
        displayCalc.setText("");
        displayHex.setText("Hex ");
        displayDec.setText("Dec ");
        displayOct.setText("Oct ");
        displayBin.setText("Bin ");
    }
    @FXML public void handlePosMin(ActionEvent event){
        String posMin;
        if(((Button)event.getSource()).getText().equals("H_del")){
            if(temp4.charAt(0) == '-'){
                temp4.deleteCharAt(0);
            }else{
                posMin = "-" + temp4.toString();
                temp4.setLength(0);
                temp4.append(posMin);
            }
        }else if(((Button)event.getSource()).getText().equals("D_del")){
            if(temp3.charAt(0) == '-'){
                temp3.deleteCharAt(0);
            }else{
                posMin = "-" + temp3.toString();
                temp3.setLength(0);
                temp3.append(posMin);
            }
        }else if(((Button)event.getSource()).getText().equals("O_del")){
            if(temp2.charAt(0) == '-'){
                temp2.deleteCharAt(0);
            }else{
                posMin = "-" + temp2.toString();
                temp2.setLength(0);
                temp2.append(posMin);
            }
            
        }else{
            if(temp.charAt(0) == '-'){
                temp.deleteCharAt(0);
            }else{
                posMin = "-" + temp.toString();
                temp.setLength(0);
                temp.append(posMin);
            }
            
        }
        displayHex.setText("Hex -" + num);
        displayDec.setText("Dec -" + num1);
        displayOct.setText("Oct -" + num2);
        displayBin.setText("Bin -" + num3);
    }
    
    @FXML public void handleDel(ActionEvent event){
        if(((Button)event.getSource()).getText().equals("H_del")){
            if (temp4.length() > 0) 
                temp4.setLength(temp4.length() - 1);
            num = temp4.toString();
            num1 = ProgCalc.createDec(temp4.toString(), 16);
            num2= ProgCalc.createOct(temp4.toString(), 16);
            num3 = ProgCalc.createBin(temp4.toString(), 16);
            displayCalc.setText(num);
        }else if(((Button)event.getSource()).getText().equals("D_del")){
            if (temp3.length() > 0) 
                temp3.setLength(temp3.length() - 1);
            num = ProgCalc.createHex(temp3.toString(), 0);
            num1 = temp3.toString();
            num2= ProgCalc.createOct(temp3.toString(), 0);
            num3 = ProgCalc.createBin(temp3.toString(), 0);
            displayCalc.setText(num1);
        }else if(((Button)event.getSource()).getText().equals("O_del")){
            if (temp2.length() > 0) 
                temp2.setLength(temp2.length() - 1);
            num = ProgCalc.createHex(temp2.toString(), 8);
            num1 = ProgCalc.createDec(temp2.toString(), 8);
            num2= temp2.toString();
            num3 = ProgCalc.createBin(temp2.toString(), 8);
            displayCalc.setText(num2);
        }else{
            if (temp.length() > 0) 
                temp.setLength(temp.length() - 1);
            num = ProgCalc.createHex(temp.toString(), 8);
            num1 = ProgCalc.createDec(temp.toString(), 8);
            num2= ProgCalc.createOct(temp.toString(), 8);
            num3 = temp2.toString();
            displayCalc.setText(num3);
        }
        displayHex.setText("Hex " + num);
        displayDec.setText("Dec " + num1);
        displayOct.setText("Oct " + num2);
        displayBin.setText("Bin " + num3);
        
    }
    
    @FXML private void handleHexEqu(ActionEvent event) {
        hNum2 = temp4.toString();
        temp4.setLength(0);
        hNum1 = ProgCalc.calc(hNum1, hNum2, hOp, 2);
        hNum1 = ProgCalc.createBin(hNum1, 0);
        num =  hNum1;
        num1 = ProgCalc.createDec(hNum1, 2);
        num2 = ProgCalc.createOct(hNum1, 2);
        num3 = ProgCalc.createBin(hNum1, 2);
        hOp = "";hNum1="";hNum2="0";
        displayCalc.setText(num);
        displayHex.setText("Hex " + num);
        displayDec.setText("Dec " + num1);
        displayOct.setText("Oct " + num2);
        displayBin.setText("Bin " + num3);
        ProgCalc.addData(num, num1, num2, num);
        num = "";
        num1 = "";
        num2 = "";
        num3 = "";
    }
    
    @FXML private void handleDecEqu(ActionEvent event) {
        dNum2 = temp3.toString();
        temp3.setLength(0);
        dNum1 = ProgCalc.calc(dNum1, dNum2, dOp, 0);
        num = ProgCalc.createHex(dNum1, 0);
        num1 = dNum1;
        num2 = ProgCalc.createOct(dNum1, 0);
        num3 = ProgCalc.createBin(dNum1, 0);
        dOp = "";dNum1="";dNum2="";
        displayCalc.setText(num1);
        displayHex.setText("Hex " + num);
        displayDec.setText("Dec " + num1);
        displayOct.setText("Oct " + num2);
        displayBin.setText("Bin " + num3);
        ProgCalc.addData(num, num1, num2, num);
        num = "";
        num1 = "";
        num2 = "";
        num3 = "";
    }
    
   @FXML private void handleOctEqu(ActionEvent event) {
        oNum2 = temp2.toString();
        temp2.setLength(0);
        oNum1 = ProgCalc.calc(oNum1, oNum2, oOp, 8);
        oNum1 = ProgCalc.createOct(oNum1, 0);
        num = ProgCalc.createHex(oNum1, 8);
        num1 = ProgCalc.createDec(oNum1, 8);
        num2 = oNum1;
        num3 = ProgCalc.createBin(oNum1, 8);
        oOp = "";oNum1="";oNum2="0";
        displayCalc.setText(num2);
        displayHex.setText("Hex " + num);
        displayDec.setText("Dec " + num1);
        displayOct.setText("Oct " + num2);
        displayBin.setText("Bin " + num3);
        ProgCalc.addData(num, num1, num2, num);
        num = "";
        num1 = "";
        num2 = "";
        num3 = "";
    }
    
    @FXML private void handleBinEqu(ActionEvent event) {
        bNum2 = temp.toString();
        temp.setLength(0);
        bNum1 = ProgCalc.calc(bNum1, bNum2, bOp, 2);
        bNum1 = ProgCalc.createBin(bNum1, 0);
        num = ProgCalc.createHex(bNum1, 2);
        num1 = ProgCalc.createDec(bNum1, 2);
        num2 = ProgCalc.createOct(bNum1, 2);
        num3 = bNum1;
        bOp = "";bNum1="";bNum2="0";
        displayCalc.setText(num3);
        displayHex.setText("Hex " + num);
        displayDec.setText("Dec " + num1);
        displayOct.setText("Oct " + num2);
        displayBin.setText("Bin " + num3);
        ProgCalc.addData(num, num1, num2, num);
        num = "";
        num1 = "";
        num2 = "";
        num3 = "";
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
}
