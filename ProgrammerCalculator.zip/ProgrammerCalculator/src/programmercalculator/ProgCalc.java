/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programmercalculator;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.Vector;
import java.util.*;

/**
 *
 * @author nayen
 */
public class ProgCalc implements Serializable{
    private static StringBuilder num = new StringBuilder();
    private static ObjectOutputStream output;
    private static ResultSet _rs=null;
    static final String DB_URL = "jdbc:derby://localhost:1527/ProgramCalc";
    static final String USERNAME = "Calc";
    static final String PASSWORD = "Program";

    ProgCalc(){
        try 
        {
            Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
        }
        catch (SQLException sqlException)
        {
           sqlException.printStackTrace();
           System.exit(1);
        }
    }
    
    
    static String createBin(String input, int rad){
        int x;
        if(rad > 0){
            x = Integer.parseInt(input, rad);
        }else{
            x = Integer.parseInt(input);
        }
        String num = Integer.toBinaryString(x);
        return num;
    }
    static String createHex(String input, int rad){
        int x;
        if(rad > 0){
            x = Integer.parseInt(input, rad);
        }else{
            x = Integer.parseInt(input);
        }
        String num = Integer.toHexString(x);
        return num;
    }
    static String createDec(String input, int rad){
        StringBuilder dec = new StringBuilder();
        int x;
        if(rad > 0){
            x = Integer.parseInt(input, rad);
        }else{
            x = Integer.parseInt(input);
        }
        dec.append(x);
        return dec.toString();
    }
    static String createOct(String input, int rad){
        int x;
        if(rad > 0){
            x = Integer.parseInt(input, rad);
        }else{
            x = Integer.parseInt(input);
        }
        String num = Integer.toOctalString(x);
        return num;
    }
    
    static String calc(String num, String num2, String op, int rad){
        StringBuilder calNum = new StringBuilder();
        int x, y, result;
        if(rad > 0){
            x = Integer.parseInt(num, rad);
            y = Integer.parseInt(num2, rad);
        }else{
            x = Integer.parseInt(num);
            y = Integer.parseInt(num2);
        }
        
        if(op.equals("/"))
            result = x/y;
        else if(op.equals("*"))
            result = x * y;
        else if(op.equals("-"))
            result = x - y;
        else if(op.equals("%"))
            result = x % y;
        else if(op.equals("AND"))
            result = x & y;
        else if(op.equals("OR"))
            result = x|y;
        else if(op.equals("XOR"))
            result = x^y;
        else if(op.equals("NAND")){
            result = x&y;
            result = ~result;
        }
        else if(op.equals("NOR")){
            result = x|y;
            result = ~result;
        }
        else
            result = x + y;
        calNum.append(result);
        return calNum.toString();
    }

    static String calcNot(String num, int rad){
        StringBuilder calc = new StringBuilder();
        int x;
        if(rad > 0)
            x = Integer.parseInt(num, rad);
        else
            x = Integer.parseInt(num);
        calc.append(~x);
        return calc.toString();
    }
    
    static void addData(String h, String d, String o, String b){
        try
        {
            Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            PreparedStatement insertData = connection.prepareStatement("INSERT INTO Result (H, D, O, B) VALUES (?,?,?,?)");
            insertData.setString(1, h);
            insertData.setString(2,d);
            insertData.setString(3,o);
            insertData.setString(4,b);
            insertData.executeUpdate();            
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
            System.exit(2);
        }
        
    }
    
    static void writeToFile(){
        System.out.println("writing all datat to Binary File");
        List<String> results = new ArrayList<String>();
        String result;
        try{
            Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            PreparedStatement selectAll = connection.prepareStatement("SELECT * FROM Result");
            _rs = selectAll.executeQuery();
            while(_rs.next()){
                 for(int i=0;i<_rs.getMetaData().getColumnCount();i++)
                       results.add(_rs.getString(i+1));
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
            System.exit(3);
        }
        
        try{
            output = new ObjectOutputStream(Files.newOutputStream(Paths.get("Calculations.ser")));
        }
        catch(IOException ioException){
            System.err.println("Error opening file. Terminating.");
        }
        for(int i = 0; i < results.size(); i++){
            try{
            output.writeObject(results.get(i));
            }
            catch (IOException ioException){
                System.err.println("Error writing to file. Terminating.");
            }
        }
        
        try{
            if (output != null)
                output.close();
        }catch (IOException ioException){
            System.err.println("Error closing file. Terminating.");
        }
                                             
    }
}
