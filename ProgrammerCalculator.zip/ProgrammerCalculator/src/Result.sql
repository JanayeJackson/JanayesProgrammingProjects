CREATE TABLE Result (
  H varchar(50) DEFAULT NULL,
  D varchar(50) DEFAULT NULL,
  O varchar(50) DEFAULT NULL,
  B varchar(50) DEFAULT NULL,
  num_id INT NOT NULL GENERATED ALWAYS AS IDENTITY,
  PRIMARY KEY (num_id)
);