package courseproject;

/**
 * Class to hold and change information related to 
 * the Community Garden project
 *
 * @author Janaye Jackson
 * @version 07/28/2022
 */

import java.util.*;
import java.util.Scanner;
import java.util.ArrayList;
import java.io.PrintWriter;
import java.io.File;
import java.io.IOException;

public class CommunityGarden implements Community
{
    // instance variables
    private String name, email, number,time, day;
    String donate[] = new String [8];
    private boolean choice;
    private ArrayList<Integer> choiceNum = new ArrayList<Integer>();

    /**
     * Constructor for objects of class CommunityGarden
     * Parameters: String, String, String
     */
    public CommunityGarden(String n, String e, String num)
    {
        name = n;
        email = e;
        number = num;
        
        donate[0] = "Monetary Donation";
        donate[1] = "Seed Donation";
        donate[2] = "Soil Donation";
        donate[3] = "Fertilizer Donation";
        donate[4] = "Voluntary Labor";
        donate[5] = "Gardening Tools";
        donate[6] = "Extra Gardening Materials";
        donate[7] = "No more";
        
        donations();
    }
    
    /*
     * Method to for user to input which donations 
     * they would like to make
     */
    public void donations()
    {
        //Create Scanner item
        Scanner sc = new Scanner(System.in);
        
        //Prompt user for input
        System.out.println("Would you like to see donation options? Y or N");
        
        //Check user input
        if(sc.nextLine().equalsIgnoreCase("Y")){
            showDonate();
            System.out.println("Which donations would you like to make?");
            int num = sc.nextInt();
            while(num != 7)
            {
                choiceNum.add(num);
                num = sc.nextInt();
            }
        }
    }
    
    /*
     * Method to show all donations options
     */
    public void showDonate()
    {
        for(int i = 0; i < donate.length; i ++)
            System.out.println("[" + i + "]" + donate[i]);
    }
    
    /*
     * Validiting user input for appointments
     */
    public boolean inputCheck(String n, String l, String d)
    {
        int dow;                //Integer to determine weekday, Sunday, or Saturday
        boolean check = true;   //Boolean return for valid user input 
        
        //Determining day of the week
        switch(d){
            case "Sun":  
                dow = 3;
                break;
            case "Sat":
                dow = 2;
                break;
            default:
                dow = 1;
        }

        //Determing if appointment is within range of days
        if(dow == 3) //Sunday not in range
        {
            System.out.println("The Community Garden is closed on Sundays");
            return false;
        }
        if(dow == 1) //Determing if appointment time is within range of hours for weekdays
        {
            if(l.equalsIgnoreCase(" AM")) //AM or PM 
            {
                if(n.compareTo("8:00") < 0){
                    System.out.println("The Community Garden is not open before 8:00 AM");
                    return false;
                }
            }
            if(l.equalsIgnoreCase(" PM"))//AM or PM
            {
                if(n.compareTo("8:00") > 0){
                    System.out.println("The Community Garden is not open after 8:00 PM");
                    return false;
                }
            }
        }
        if(dow == 2) //Determing if appointment time is within range of hours for Saturday
        {
            if(l.equalsIgnoreCase(" AM")) //AM or PM
            {
                if(n.compareTo("8:00") < 0){
                    System.out.println("The Community Garden is not open before 8:00 AM");
                    return false;
                }
            }
            if(l.equalsIgnoreCase(" PM"))//AM or PM
            {
                if(n.compareTo("5:00") > 0){
                    System.out.println("The Community Garden is not open after 5:00 PM");
                    return false;
                }
            }
        }
        
        return check;//If all values are in range returns true else returns false
    }
    
    /*
     * Method to put all information into a text file
     */
    public void outputFile(String time, String day) throws Exception
    {
        PrintWriter outFile = new PrintWriter(new File("User Infomration.txt"));
        outFile.println("Name: " + name);
        outFile.println("Email: " + email);
        outFile.println("Phone Number: " + number);
        
        outFile.println("Your Appointment is set for " + time + " on " + day.substring(0, 10));
        if(choiceNum.size() != 0)
        {
            outFile.print("You have chosen the following donation option(s): ");
            for(int i = 0; i < choiceNum.size(); i++)
                outFile.print(donate[choiceNum.get(i)] + " ");
        }
    }
    
}
