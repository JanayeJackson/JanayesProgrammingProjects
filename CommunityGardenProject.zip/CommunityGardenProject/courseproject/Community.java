package courseproject;


/**
 * Interface with methods donations(), showDonate(),
 * outputFile(), inputCheck().
 *
 * @author Janaye Jackson
 * @version 07/28/2022
 */
public interface Community
{
    void donations();
    void showDonate();
    void outputFile(String a, String b) throws Exception;
    boolean inputCheck(String a, String b, String c);
}
