package courseproject;

/**
 * Class to recieve user input regarding 
 * the Community Garden project
 * 
 * Creates a frame and accepts user input 
 * in many forms
 *
 * @author Janaye Jackson
 * @version 07/28/2022
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.util.*;
import java.util.Scanner;
import org.jdatepicker.*;
import org.jdatepicker.util.*;
import org.jdatepicker.impl.*;

public class UserDate implements ActionListener
{
    //Create Date Picker
    UtilDateModel model;
    Properties p;
    JDatePanelImpl panel;
    JDatePickerImpl datePicker;
    static String dateS;
    static String time;
    JFrame jfrm;
    
    /**
     * Constructor for objects of class Date
     */
    public UserDate()
    {
        //Create a new JFrame container
        jfrm = new JFrame("Communty Garden");
        
        //Set JFrame Layout
        jfrm.setLayout(new FlowLayout());
        
        //Set JFrame size
        jfrm.setSize(300, 500);
        
        //Close JFrame on exit
        jfrm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //Initialize Date Picker
        model = new UtilDateModel();
        p = new Properties();
        panel = new JDatePanelImpl(model, p);
        datePicker = new JDatePickerImpl(panel, new DateLabelFormatter());
        
        //Add components to frame
        jfrm.add(datePicker);
        
        //Displaying the frame
        jfrm.setVisible(true);
        
        //Add action to datePicker
        datePicker.addActionListener(this);
    }
    
    public void actionPerformed(ActionEvent ae)
    {
        Date dateD = (Date)datePicker.getModel().getValue(); //Get date user picked
        jfrm.setVisible(false); //remove JFrame
        dateS = dateD + "";     //Add user date to string
        
        //Outputting user picked appointment
        if(dateS != ""){
            System.out.println("Your appointment is on " + dateS.substring(0, 10) + " at " + time);
        }
    }

    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);  //Create new scanner
        String timeNum, timeLet;              //Strings for time
        
        //Initialize Variables
        timeNum = "";                       
        timeLet = "";
        
        //Header for contact information
        System.out.println("                General Contact Information");
        System.out.print("Name: ");
        String name = sc.nextLine();
        System.out.print("Email: ");
        String email = sc.nextLine();
        System.out.print("Phone number: ");
        String number = sc.nextLine();
        
        if(name != "" && email != "" && number != "")
        {
            //header
            System.out.println("Welcome to Moreno Valley Colleges Community Garden");
            System.out.println("Hours: Monday - Friday (8:00 AM to 8:00 PM)");
            System.out.println("       Saturday (8:00 AM to 5:00PM)");
            System.out.println("       Sunday (closed)");
            //User input
            System.out.println("What time would you like your appointment");
            timeNum = sc.next();
            timeLet = sc.nextLine();
            time = timeNum + " " + timeLet.substring(1,3);
            
            System.out.println("What day would you like to scheldule your apointment");
        }    
        
        //Create the frame on the event dispatching thread.
        SwingUtilities.invokeLater(new Runnable(){
            public void run(){
                new UserDate();
                }
        });
        
        //Create an object of Community Garden
        CommunityGarden user1 = new CommunityGarden(name, email, number);
        
        //Check to make sure all User Input is valid
        if(user1.inputCheck(timeNum, timeLet, dateS.substring(0,3)))
            user1.outputFile(time, dateS); //output all info to text file
    }
}
